<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Versi</b> 0.1
    </div>
    <strong>Hak Cipta &copy; <?= date('Y'); ?>. Anisa Latar</strong> ITB STIKOM AMBON. | Repost by Anisa</a>
    
</footer>